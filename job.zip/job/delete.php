<!DOCTYPE html>
<html>
<head>
</head>
<body>
<form method="post" action="router.php?operation=3">
<input type="text" name="id" placeholder="job id"><br>
<input type="submit" value="enter">
</form>
</body>
</html>
