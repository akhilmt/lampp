<?php
include"helper.php";
$op=$_REQUEST['operation'];
switch($op)
{
case 1:

$title=$_REQUEST['job_title'];
$desc=$_REQUEST['job_desc'];
$salary=$_REQUEST['salary'];
$location=$_REQUEST['location'];
job_insert($title,$desc,$salary,$location);
break;

case 2:

$id=$_REQUEST['id'];
$title=$_REQUEST['job_title'];
$desc=$_REQUEST['job_desc'];
$salary=$_REQUEST['salary'];
$location=$_REQUEST['location'];
//job_delete($id);
job_update($id,$title,$desc,$salary,$location);
case 3:
$id=$_REQUEST['id'];
job_delete($id);

default:job_select();
}
?>
<a href="form.php">   click here for to show tables</a>
