<!DOCTYPE html>
<html>
<head>
</head>
<body>
<form method="post" action="router.php?operation=1">

<input type="text" name="job_title" placeholder="job title"><br>
<input type="text" name="job_desc" placeholder="job description"><br>
<input type="number" name="salary" placeholder="salary"><br>
<input type="text" name="location" placeholder="location"><br>
<input type="submit" value="enter"><br>
<a href="form.php">click here for to show tables</a><br>
<a href="update.php">click here for to update</a><br>
<a href="delete.php">click here for to delete</a><br>

</body>
<html>
