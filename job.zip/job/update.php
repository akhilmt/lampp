
<!DOCTYPE html>
<html>
<head>
</head>
<body>
<form method="post" action="router.php?operation=2">
<input type="text" name="id" placeholder="job id"><br>
<input type="text" name="job_title" placeholder="job title"><br>
<input type="text" name="job_desc" placeholder="job description"><br>
<input type="number" name="salary" placeholder="salary"><br>
<input type="text" name="location" placeholder="location"><br>
<input type="submit" value="enter">
</form>
</body>
</html>



